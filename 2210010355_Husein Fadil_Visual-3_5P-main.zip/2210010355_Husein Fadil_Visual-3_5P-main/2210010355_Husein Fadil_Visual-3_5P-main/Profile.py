import PySimpleGUI as sg
window = sg.Window('Profile', 
    [[sg.Text('NPM :2210010355'),],
        [sg.Text('Nama :Husein Fadil')], 
        [sg.Text('kelas :5P Reguler Banjarmasin')],
        [sg.Text('matkul : Pemograman Visual')],
    ],size=(500,200))
event, values=window.read()
window.close()
