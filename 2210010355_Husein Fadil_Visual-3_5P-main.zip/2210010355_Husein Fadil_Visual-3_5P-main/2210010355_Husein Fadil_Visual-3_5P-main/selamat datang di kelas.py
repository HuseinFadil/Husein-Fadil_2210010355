import PySimpleGUI as sg
window = sg.Window('Selamat Datang Di Kelas', 
    [[sg.Text("Selamat datang di kelas", font=("Arial",25,"italic","bold","underline",))],
        [sg.Text('NPM       : 2210010355'),],
        [sg.Text('Nama      : Husein Fadil')], 
        [sg.Text('kelas     : 5P Reguler Banjarmasin')],
        [sg.Text('matkul    : Pemograman Visual')],
    ],size=(500,200))
event, values=window.read()
window.close()
