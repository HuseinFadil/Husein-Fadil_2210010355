import PySimpleGUI as sg
window = sg.Window(title="Latihan Pertama", layout=[[]], size=(500,300))
event, values=window.read()
window.close()