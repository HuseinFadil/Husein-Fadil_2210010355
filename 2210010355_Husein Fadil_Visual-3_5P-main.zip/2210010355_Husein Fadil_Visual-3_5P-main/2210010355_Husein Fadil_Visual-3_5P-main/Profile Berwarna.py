import PySimpleGUI as sg
sg.theme("LightGreen8")
sg.theme_text_color("#00ffff")
windos = sg.Window('Profile Berwarna', 
    [[sg.Text('NPM :2210010355'),],
        [sg.Text('Nama :Husein Fadil')], 
        [sg.Text('kelas :5P Reguler Banjarmasin')],
        [sg.Text('matkul : Pemograman Visual')],
    ],size=(500,200)).read(close=True)
event, values=window.read()
window.close()